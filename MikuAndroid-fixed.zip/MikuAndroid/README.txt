M-AI Miku Android project

This Android Studio project packages the supplied Arabic M-AI Miku chat page in an Android WebView.

ONLINE + OFFLINE BEHAVIOUR
- AUTO (recommended): uses saved knowledge and local replies first; if internet is available, it can search online when needed. If the connection drops, it falls back to the saved/offline knowledge.
- OFFLINE: uses the knowledge and facts saved inside the app on the phone. It does not fetch current news, weather, or web pages.
- ONLINE: tries to use internet search. An internet connection is required.
- User-taught facts and learned search snippets are saved locally in the app's browser storage.

IMPORTANT LIMITS
- Offline answers come from the built-in knowledge and what the user teaches Miku. This is not the same as a full offline ChatGPT model.
- The optional WebLLM model needs a compatible Android WebView with WebGPU and a large download. It may not work on all phones; low-memory devices may struggle.
- Online search uses public services (Wikipedia, DuckDuckGo, and Open-Meteo). Those services can be unavailable or block requests at times.
- The app's HTML and avatar are bundled in the APK, so the basic interface and saved knowledge are available without internet.

BUILD APK
1. Install Android Studio on a computer.
2. Open the MikuAndroid folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if requested.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

The app loads bundled assets through AndroidX WebKit's HTTPS asset loader so web requests have a secure app origin instead of file://. No compiled APK is included in this project archive.


تم استبدال صورة ميكو الافتراضية بالصورة التي أرسلها المستخدم (Hatsune Miku chibi).


تعديلات: إصلاح الشريط العلوي في Android 15، أيقونة التطبيق، إزالة ملفات PWA المفقودة، تضييق الصلاحيات، وإضافة gradle-wrapper.properties (Gradle 8.9).
